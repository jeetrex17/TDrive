# TDrive Editable SVG Asset Pack

This pack contains true editable SVG assets for TDrive, inspired by the previously generated mobile and desktop UI boards.

## Included
- Brand assets
- Action icons
- File type icons
- Folder icons
- Buttons
- Status chips
- Search/navigation components
- Empty-state/helper illustrations

These SVGs are built from real vector shapes, strokes, fills, and text.
